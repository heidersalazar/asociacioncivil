<head>
<!--Lineas para poder usar el framework Boostrap-->
 <link rel="stylesheet" href="css/bootstrap.min.css">
 <link rel="stylesheet" type="text/css" href="fonts/css/all.css">
 <script src="js/jquery.min.js" ></script>
 <script src="js/bootstrap.min.js" ></script>
</head>